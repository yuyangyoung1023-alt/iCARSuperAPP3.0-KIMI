#!/usr/bin/env python3
"""Local-only standalone launcher. No dependencies beyond Python 3."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import webbrowser

root = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
try:
    server = ThreadingHTTPServer(('127.0.0.1', 8767), handler)
except OSError:
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
url = 'http://127.0.0.1:%d/' % server.server_port
print('iCAR Claw超级APP3.0：' + url, flush=True)
print('保持此窗口打开。按 Control+C 停止服务。', flush=True)
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
